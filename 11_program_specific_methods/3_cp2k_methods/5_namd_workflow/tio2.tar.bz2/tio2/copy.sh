#!/bin/bash
for i in {1000..1500}; do
  #cp tmp_logfiles/step_${i}.log all_logfiles/step_${i}.log
  cp tmp_res/E_ks_${i}.npz res/E_ks_${i}.npz
  cp tmp_res/S_ks_${i}.npz res/S_ks_${i}.npz
  cp tmp_res/St_ks_${i}.npz res/St_ks_${i}.npz
done
