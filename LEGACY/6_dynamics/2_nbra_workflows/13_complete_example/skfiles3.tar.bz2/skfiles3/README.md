The .skf files can be generated via the following command:

Activate skpgogs environmanet if needed. Then:

    skgen -o slateratom -t sktwocnt sktable -d C,H,O,Ti C,H,O,Ti


Make sure, the maximal distance for the radial grid isn't too large

