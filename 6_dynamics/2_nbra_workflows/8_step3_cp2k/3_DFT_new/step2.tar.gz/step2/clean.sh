rm -r job*
rm -r all_*
rm -r res
