copied from /panasas/scratch/grp-alexeyak/mohammad/1_project_xtb/Si1009H412/step2


1. Edit run_template.py

2. Edit submit_template.slm   if needed

3. Edit   es_diag_temp.inp   (copy md input and change the runtype to energy)

4. Edit distribute_jobs.py  

5.  python distribute_jobs.py

